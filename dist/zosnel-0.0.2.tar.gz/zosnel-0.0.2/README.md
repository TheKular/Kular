# Zosnel &middot; ![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)
[Zosnel] is a project helping Python developers write code in HTML, CSS, JS all while using Python. Currently the project is in development and not ready for full public use.

Zosnel (Zo - Snel) is a open source project made for easy creation of websites using only python.